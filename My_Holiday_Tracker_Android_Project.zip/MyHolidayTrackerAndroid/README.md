# My Holiday Tracker — Android project

This is an Android app project that packages the existing offline Holiday Tracker inside a simple Android WebView shell. The HTML, CSS, and JavaScript are bundled inside the app; the app does not need internet access to run.

## Important

This folder is **source project files, not an APK**. The APK is produced by the included GitHub Actions workflow.

## Build in the cloud (no Android Studio needed on your Primebook)

1. Sign in to GitHub in your browser and create a new repository, e.g. `my-holiday-tracker`.
2. Upload the contents of this folder to the repository (not the parent folder itself). Ensure `.github/workflows/build-apk.yml` is included. If GitHub's web uploader hides `.github`, create/upload the workflow through the repository's Add file interface or use a desktop browser's upload flow.
3. Open the repository's **Actions** tab and select **Build My Holiday Tracker APK**.
4. Choose **Run workflow** if it has not started automatically, then wait for the run to finish successfully.
5. In the completed workflow run, scroll to **Artifacts** and download `My-Holiday-Tracker-APK`.
6. Extract the downloaded artifact ZIP; inside is `app-debug.apk`. Transfer/download that APK to your Primebook and install it, allowing installs from that source if Android asks.

The first build requires internet for GitHub Actions to download the Android SDK and build dependencies. The installed app itself is designed to work offline.
